# ejercicio3.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [15.0, 20.0, 18.0, 25.0, 22.0, 17.0, 19.0, 23.0, 21.0, 16.0]
Y = [5.0, 7.0, 6.0, 11.0, 9.0, 6.0, 7.0, 10.0, 8.0, 5.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
