# ejercicio1.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [38.0, 45.0, 31.0, 50.0, 27.0, 41.0]
Y = [22.0, 28.0, 39.0, 33.0, 36.0, 29.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
