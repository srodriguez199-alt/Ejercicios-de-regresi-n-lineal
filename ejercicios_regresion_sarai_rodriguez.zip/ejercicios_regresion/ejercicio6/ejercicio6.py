# ejercicio6.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [1.2, 1.8, 2.4, 3.5, 5.0, 7.5, 10.0]
Y = [2.1, 2.7, 3.0, 4.2, 5.0, 6.5, 7.3]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
