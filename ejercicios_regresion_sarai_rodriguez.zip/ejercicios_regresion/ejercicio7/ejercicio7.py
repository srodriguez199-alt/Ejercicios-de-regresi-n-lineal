# ejercicio7.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [10.0, 30.0, 50.0, 70.0, 90.0, 110.0, 130.0]
Y = [2.2, 3.8, 6.1, 11.7, 19.2, 24.2, 36.9]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
