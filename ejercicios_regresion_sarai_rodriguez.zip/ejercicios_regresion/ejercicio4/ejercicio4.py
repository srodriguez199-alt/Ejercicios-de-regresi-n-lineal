# ejercicio4.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [3.7, 5.0, 7.0, 6.5, 2.2, 5.5, 2.9, 4.2, 3.4, 2.5, 1.5, 3.7, 4.9, 3.2, 2.2, 1.6, 2.3, 2.9, 3.2, 3.7, 4.4, 4.8, 5.0]
Y = [9.18, 8.54, 6.85, 8.98, 5.2, 7.15, 7.88, 5.65, 3.26, 2.25, 1.95, 3.34, 7.23, 4.45, 2.05, 1.43, 2.44, 2.95, 3.16, 3.95, 4.25, 5.39, 5.64]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
