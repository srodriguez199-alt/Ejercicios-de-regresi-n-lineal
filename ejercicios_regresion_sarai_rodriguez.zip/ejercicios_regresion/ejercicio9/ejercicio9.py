# ejercicio9.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [636.0, 275.0, 398.0, 405.0, 286.0, 627.0, 2346.0, 177.0, 2528.0, 248.0, 512.0, 248.0, 248.0, 237.0, 621.0, 853.0, 2181.0, 1531.0, 2724.0, 999.0]
Y = [109.0, 129.0, 141.0, 152.0, 165.0, 259.0, 231.0, 148.0, 224.0, 125.0, 225.0, 124.0, 125.0, 137.0, 191.0, 191.0, 249.0, 229.0, 243.0, 219.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
