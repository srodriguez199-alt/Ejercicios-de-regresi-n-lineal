# ejercicio2.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [4.0, 7.0, 10.0, 6.0, 8.0, 9.0, 5.0, 11.0, 7.0, 6.0, 8.0, 10.0]
Y = [65.0, 70.0, 85.0, 78.0, 82.0, 91.0, 74.0, 94.0, 80.0, 77.0, 84.0, 88.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
