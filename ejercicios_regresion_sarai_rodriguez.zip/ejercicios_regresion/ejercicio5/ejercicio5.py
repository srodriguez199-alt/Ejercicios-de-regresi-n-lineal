# ejercicio5.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
Y = [45.0, 112.0, 228.0, 485.0, 900.0, 1720.0, 3526.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
