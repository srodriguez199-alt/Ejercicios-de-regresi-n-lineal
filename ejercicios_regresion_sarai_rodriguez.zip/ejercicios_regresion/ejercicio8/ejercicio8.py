# ejercicio8.py - reproducible script (simplified)
import numpy as np
from scipy import stats

X = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
Y = [42.0, 110.0, 220.0, 495.0, 910.0, 1730.0, 3500.0]

slope, intercept, r_value, p_value, stderr = stats.linregress(X,Y)
print('Ŷ = {:.6f} + {:.6f}·X'.format(intercept, slope))
print('r =', r_value, 'R2 =', r_value**2)
